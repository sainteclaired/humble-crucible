"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.
"""

from __future__ import annotations

import ast
import itertools
import json
import math
import os
import re
import time
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext

_TRANSLATOR_PROMPT = """You translate a logic puzzle into a formal model that a program will solve.

Return ONLY a JSON object, no prose:
{
  "applicable": true,
  "items": ["<id>", ...],
  "attributes": {
    "<attr>": {"values": [...], "distinct": true},
    ...
  },
  "constraints": [{"clue": <clue number>, "expr": "<expression>"}, ...]
}

Model:
- items: the things being ordered or assigned, using short ids exactly as the puzzle names them.
- Each item gets exactly one value of every attribute. "distinct": true means no two items share a value
  (positions, one-pet-each); false means values may repeat (e.g. "knight": {"values": [true, false], "distinct": false}).
- For an order or sequence, use an attribute "position" with values 1..N, 1 = first/earliest/leftmost/top/winner,
  matching the direction the puzzle asks for.

Expressions are Python-like and may use only:
- attr['item']         the value an item has, e.g. position['E2'], pet['Ava']
- who('attr', value)   the item that has a value of a distinct attribute, e.g. position[who('pet', 'cat')]
- count('attr', value) how many items have that value, e.g. count('knight', True) == 2
- numbers, quoted strings, true/false as True/False, + - * % //, abs(),
  == != < <= > >=, in / not in with a tuple, and / or / not, parentheses.
- "A implies B" is written (not A) or B. "X says S" for a truth-teller/liar puzzle is knight['X'] == (S).

Rules:
- Every clue number must appear in at least one constraint. A clue that only introduces items gets expr "True".
- Translate each clue literally; do not solve the puzzle and do not add constraints the clues do not state.
- Statements under "Other statements" are optional: translate those that constrain this puzzle with
  "clue": 0, and ignore the rest.
- If the puzzle is not a finite assignment/ordering/truth-teller problem (arithmetic, ciphers, sequences,
  trivia), return {"applicable": false}."""

_EXPR_NODES = (
    ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd,
    ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Mod, ast.FloorDiv, ast.Compare, ast.Eq, ast.NotEq,
    ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn, ast.Name, ast.Load, ast.Constant,
    ast.Subscript, ast.Tuple, ast.List, ast.Call, ast.IfExp,
)
_EXPR_HELPERS = {"who", "count", "abs"}
_MAX_CANDIDATES_PER_ATTRIBUTE = 50_000
_MAX_SOLUTIONS = 4


def _compile_constraint(expr: str, attributes: set[str]) -> tuple[Any, set[str]] | None:
    """Validate a constraint expression and return (code, attributes it reads).

    Only the node types above are allowed and every bare name must be an
    attribute or a helper, so eval cannot reach builtins, attributes, or
    imports. None means the expression is not in the language.
    """
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        return None
    used: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, _EXPR_NODES):
            return None
        if isinstance(node, ast.Constant) and not isinstance(node.value, (int, str, bool)):
            return None
        if isinstance(node, ast.Name):
            if node.id in attributes:
                used.add(node.id)
            elif node.id not in _EXPR_HELPERS:
                return None
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in _EXPR_HELPERS or node.keywords:
                return None
            if node.func.id in ("who", "count"):
                first = node.args[0] if node.args else None
                if not (isinstance(first, ast.Constant) and first.value in attributes):
                    return None
                used.add(first.value)
    return compile(tree, "<constraint>", "eval"), used


def solve_model(model: dict[str, Any], clue_count: int, budget_s: float = 3.0) -> list[dict[str, dict[str, Any]]] | None:
    """Solve a translated puzzle model; every solution maps attr -> {item: value}.

    Returns None when the model is malformed, skips a clue, uses an expression
    outside the language, is too large to search within the budget, has no
    solution (the translation must be wrong), or has more than
    _MAX_SOLUTIONS solutions (more likely a loose translation than a puzzle
    with that many answers).
    """
    items = [str(item) for item in model.get("items") or []]
    raw_attributes = model.get("attributes") or {}
    if len(items) < 2 or len(set(items)) != len(items) or not isinstance(raw_attributes, dict) or not raw_attributes:
        return None
    attributes: dict[str, tuple[list[Any], bool]] = {}
    for name, spec in raw_attributes.items():
        if not str(name).isidentifier() or not isinstance(spec, dict) or not spec.get("values"):
            return None
        values, distinct = list(spec["values"]), bool(spec.get("distinct", True))
        size = math.perm(len(values), len(items)) if distinct else len(values) ** len(items)
        if (distinct and len(values) < len(items)) or size > _MAX_CANDIDATES_PER_ATTRIBUTE:
            return None
        attributes[str(name)] = (values, distinct)

    order = list(attributes)
    constraints_by_level: dict[int, list[Any]] = {index: [] for index in range(len(order))}
    covered: set[int] = set()
    for constraint in model.get("constraints") or []:
        compiled = _compile_constraint(str(constraint.get("expr", "")), set(attributes))
        if compiled is None:
            return None
        code, used = compiled
        level = max((order.index(name) for name in used), default=0)
        constraints_by_level[level].append(code)
        if isinstance(constraint.get("clue"), int):
            covered.add(constraint["clue"])
    if not set(range(1, clue_count + 1)) <= covered:
        return None

    assignment: dict[str, dict[str, Any]] = {}

    def who(attr: str, value: Any) -> str | None:
        return next((item for item, v in assignment[attr].items() if v == value), None)

    def count(attr: str, value: Any) -> int:
        return sum(1 for v in assignment[attr].values() if v == value)

    env: dict[str, Any] = {"who": who, "count": count, "abs": abs}
    deadline = time.monotonic() + budget_s
    solutions: list[dict[str, dict[str, Any]]] = []

    def search(level: int) -> bool:
        """Depth-first over attributes; False aborts the whole search."""
        if level == len(order):
            solutions.append({attr: dict(values) for attr, values in assignment.items()})
            return len(solutions) <= _MAX_SOLUTIONS
        name = order[level]
        values, distinct = attributes[name]
        combos = itertools.permutations(values, len(items)) if distinct else itertools.product(values, repeat=len(items))
        for combo in combos:
            if time.monotonic() > deadline:
                return False
            assignment[name] = dict(zip(items, combo))
            env[name] = assignment[name]
            try:
                ok = all(eval(code, {"__builtins__": {}}, env) for code in constraints_by_level[level])
            except Exception:
                ok = False
            if ok and not search(level + 1):
                return False
        assignment.pop(name, None)
        env.pop(name, None)
        return True

    if not search(0) or not solutions:
        return None
    return solutions


def _render_solution(solution: dict[str, dict[str, Any]]) -> str:
    """One line per solution: items in position order when there is one."""
    sort_attr = next(
        (a for a, v in solution.items() if all(isinstance(x, int) and not isinstance(x, bool) for x in v.values())),
        None,
    )
    items = list(next(iter(solution.values())))
    if sort_attr:
        items.sort(key=lambda item: solution[sort_attr][item])
    others = [a for a in solution if a != sort_attr]
    parts = []
    for item in items:
        detail = ", ".join(f"{a}={solution[a][item]}" for a in others)
        parts.append(f"{item} ({detail})" if detail else item)
    prefix = f"by {sort_attr}: " if sort_attr else ""
    return prefix + ", ".join(parts)


def _parse_json_object(text: str) -> dict[str, Any] | None:
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.DOTALL)
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        value = json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def _alias(model: str) -> str:
    return str(model or "").strip().rsplit("/", 1)[-1].casefold()


def _family(model: str) -> str:
    match = re.match(r"[a-z]+", _alias(model))
    return match.group(0) if match else _alias(model)


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "my-agent"
    agent_name = "My Team"

    # Text challenge strategy
    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."
    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Preferred text models, best first. The runtime cuts a model off at a
    # deadline and falls back to the next one, so the first entry may be a
    # slower model that answers more puzzles.
    text_model_preference = (
        "gemini-3.6-flash",
        "gpt-5.6-terra",
        "gemini-3.8-flash",
        "nemotron-3.5-lightning",
        "qwen3.7-max",
        "qwen3.7-plus",
        "nemotron-3-ultra",
    )
    # Tried only after every other model, including unlisted ones.
    text_model_last_resort = (
        "gpt-5.4",
        "qwen3.7-flash",
        "nemotron-3-super",
        "qwen3.6-35b",
    )

    # Ask a model to translate the clues into a constraint model and solve
    # that in code. Costs one extra LLM call per clue-based challenge.
    use_translator = True
    translator_max_tokens = 4096
    # Fraction of the challenge time limit the translation call may take
    # (clamped to 5-20 s).
    translator_time_share = 0.15

    # A problem-independent way to break a puzzle down.
    general_method = (
        "How to work (in your reasoning, not in the output):\n"
        "1. Goal: state exactly what is asked and the answer format the Rules require.\n"
        "2. Unknowns: list what must be determined and the possible values of each.\n"
        "3. Facts: restate every clue or given fact precisely, in one consistent vocabulary.\n"
        "4. Fix what is forced: apply facts that settle a value outright; "
        "group things that must go together.\n"
        "5. Narrow, then branch: rule out impossible values first; when you must try cases, "
        "branch on the unknown with the fewest options and drop a case as soon as it breaks a fact.\n"
        "6. Check: test the answer against every fact, one by one, and against the format.\n"
        "7. If several answers pass the check, the facts allow all of them: pick one and stop. "
        "If none passes, re-read the facts from step 3."
    )

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        """Preferred models first, unknown ones next, last-resort ones last.

        Only aliases in the live roster are returned, so a changed roster still
        works: unfamiliar models keep their roster order. The runtime retries
        with the second entry, so it is kept to a different model family.
        """
        if self.is_image_challenge(ctx):
            return super().rank_models(ctx, available_models)
        preferred = [_alias(m) for m in self.text_model_preference]
        last_resort = [_alias(m) for m in self.text_model_last_resort]
        roster = list(dict.fromkeys(m for m in available_models if str(m or "").strip()))
        known = sorted((m for m in roster if _alias(m) in preferred), key=lambda m: preferred.index(_alias(m)))
        weak = sorted((m for m in roster if _alias(m) in last_resort), key=lambda m: last_resort.index(_alias(m)))
        unknown = [m for m in roster if m not in known and m not in weak]
        ranked = known + unknown + weak
        if len(ranked) > 2 and _family(ranked[1]) == _family(ranked[0]):
            other = next((m for m in ranked[2:] if _family(m) != _family(ranked[0])), None)
            if other:
                ranked.remove(other)
                ranked.insert(1, other)
        return ranked

    def _translated(self, ctx: ChallengeContext) -> list[dict[str, dict[str, Any]]] | None:
        """Solutions of an LLM translation of the clues, or None.

        Never raises: a hook exception would end the run. Results are cached
        per puzzle because the runtime rebuilds the prompt when it retries.
        """
        clues = [clue for clue in ctx.clues if clue.strip()]
        if not self.use_translator or len(clues) < 2:
            return None
        # Statements the runtime found on the server (tool results, decoded
        # text). They are offered as optional constraints, numbered 0.
        facts = [str(fact).strip() for fact in (getattr(ctx, "extra_facts", None) or []) if str(fact).strip()]
        key = (ctx.description, ctx.rules, tuple(clues), tuple(facts))
        cache = self.__dict__.setdefault("_translation_cache", {})
        if key in cache:
            return cache[key]
        cache[key] = None
        try:
            from openai import OpenAI

            from arena_clients.config import get_proxy_host
            from arena_clients.proxy_headers import build_proxy_headers
            from model_selector import resolve_proxy_api_key

            models = self.rank_models(ctx, list(ctx.available_models))
            if not models:
                return None
            timeout_s = max(5.0, min(20.0, self.translator_time_share * float(ctx.max_time_s or 60)))
            client = OpenAI(
                base_url=get_proxy_host(),
                api_key=resolve_proxy_api_key(),
                default_headers=build_proxy_headers(os.getenv("AGENT_ID") or self.agent_id),
                timeout=timeout_s,
                max_retries=0,
            )
            numbered = "\n".join(f"{index}. {clue}" for index, clue in enumerate(clues, 1))
            content = f"Description: {ctx.description}\nRules: {ctx.rules}\nClues:\n{numbered}"
            if facts:
                listed = "\n".join(f"- {fact}" for fact in facts)
                content += (
                    "\n\nOther statements (found on the server; may or may not be about this puzzle):\n"
                    f"{listed}"
                )
            response = client.chat.completions.create(
                model=models[0],
                messages=[
                    {"role": "system", "content": _TRANSLATOR_PROMPT},
                    {"role": "user", "content": content},
                ],
                max_tokens=self.translator_max_tokens,
                temperature=0.0,
            )
            model = _parse_json_object(response.choices[0].message.content or "")
            if not model or not model.get("applicable"):
                return None
            cache[key] = solve_model(model, len(clues))
        except Exception as exc:
            print(f"   Constraint translation skipped ({type(exc).__name__})", flush=True)
            return None
        solved = cache[key]
        print(f"   Constraint translation: {len(solved) if solved else 'no'} solution(s)", flush=True)
        return solved

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        prompt = super().build_solver_prompt(ctx)
        sections = [prompt, self.general_method]
        if ctx.max_time_s:
            sections.append(
                f"Time limit: {int(ctx.max_time_s)} seconds for the whole task, and speed is scored. "
                "Stop reasoning as soon as an answer passes the check."
            )
        translated = self._translated(ctx)
        if translated:
            listed = "\n".join(f"- {_render_solution(solution)}" for solution in translated)
            # A translation can misread a clue, so the model is asked to
            # verify rather than copy. When several solutions pass, the clues
            # do not decide between them; "give the first" is arbitrary and
            # exists to stop the model spending its time budget deliberating.
            sections.append(
                "A program solved a formal translation of the clues. The translation may misread a "
                "clue, so verify before using it: check the solution(s) below against the original "
                "clues. If one passes, use it (if several pass, give the first); if none passes, "
                f"solve the puzzle yourself.\n{listed}"
            )
        return "\n\n".join(sections)
