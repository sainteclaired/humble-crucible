"""A ledger of what earlier challenges on this server showed.

The live event runs each challenge in its own process. If the sandbox keeps
its scratch directory between them, a run can leave a note for the next one:
tools beyond the known set (with their parameters and descriptions),
statements found on the server, resources, and the server's instructions.

Each run appends one JSON line after its discovery pass; the next run reads
the file at startup and shows what it holds in a clearly labelled, low
priority section of the solver prompt, and to the exploration loop as
evidence. Practice entries carry nothing beyond the known tools and render
to nothing, so practice prompts are unchanged.

Everything here is best effort and never raises: a missing, unwritable or
corrupt ledger means "no notes".
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from explore import CORE_TOOLS

MAX_ENTRIES = 20       # entries kept and read
MAX_LINES = 8          # prompt lines rendered
LINE_CHARS = 400       # per rendered line
MAX_FACTS = 6          # statements kept per entry
FACT_CHARS = 200
DESCRIPTION_CHARS = 160
RESOURCE_CHARS = 300
INSTRUCTIONS_CHARS = 300


def ledger_path(agent_id: str, root: Path) -> Path:
    """`ARENA_LEDGER_PATH`, or `<root>/outputs/<agent_id>-ledger.jsonl`."""
    override = str(os.getenv("ARENA_LEDGER_PATH") or "").strip()
    if override:
        return Path(override)
    safe_id = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in str(agent_id or "agent"))
    return Path(root) / "outputs" / f"{safe_id}-ledger.jsonl"


def read_ledger(path: Path) -> list[dict[str, Any]]:
    """The last MAX_ENTRIES entries, oldest first; never raises."""
    try:
        text = Path(path).read_text(encoding="utf-8")
    except Exception:
        return []
    entries: list[dict[str, Any]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except ValueError:
            continue
        if isinstance(entry, dict):
            entries.append(entry)
    return entries[-MAX_ENTRIES:]


def write_entry(path: Path, entry: dict[str, Any]) -> bool:
    """Append one entry; never raises."""
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
        return True
    except Exception:
        return False


def _name(tool_def: object) -> str:
    return str(getattr(tool_def, "name", "") or "").strip()


def _schema_summary(tool_def: object) -> dict[str, Any]:
    schema = getattr(tool_def, "inputSchema", None) or {}
    properties = dict(schema.get("properties") or {}) if isinstance(schema, dict) else {}
    required = list(schema.get("required") or []) if isinstance(schema, dict) else []
    description = str(getattr(tool_def, "description", "") or "").strip()
    return {
        "parameters": [name for name in properties if name != "agent_id"],
        "required": [name for name in required if name != "agent_id"],
        "description": description[:DESCRIPTION_CHARS],
    }


def build_entry(
    *,
    agent_id: str,
    challenge_id: str,
    puzzle_id: str = "",
    challenge_type: str = "",
    tools: list[str] | None = None,
    tool_defs: list | None = None,
    server_instructions: str = "",
    resource_texts: dict[str, str] | None = None,
    facts: list[str] | None = None,
) -> dict[str, Any]:
    """One ledger entry: identity, the tools beyond the known set, and what was found."""
    names = [str(name or "").strip() for name in (tools or [])]
    names = [name for name in names if name]
    extra_tools = [name for name in names if name not in CORE_TOOLS]
    defs = {_name(tool_def): tool_def for tool_def in (tool_defs or []) if _name(tool_def)}
    schemas = {name: _schema_summary(defs[name]) for name in extra_tools if name in defs}
    kept_facts: list[str] = []
    for fact in facts or []:
        text = str(fact or "").strip()[:FACT_CHARS]
        if text and text not in kept_facts:
            kept_facts.append(text)
        if len(kept_facts) >= MAX_FACTS:
            break
    return {
        "recorded_at": time.time(),
        "agent_id": str(agent_id or ""),
        "challenge_id": str(challenge_id or ""),
        "puzzle_id": str(puzzle_id or ""),
        "challenge_type": str(challenge_type or ""),
        "tools": names,
        "extra_tools": extra_tools,
        "tool_schemas": schemas,
        "server_instructions": str(server_instructions or "").strip()[:INSTRUCTIONS_CHARS],
        "resources": {
            str(uri): str(text or "").strip()[:RESOURCE_CHARS]
            for uri, text in (resource_texts or {}).items()
            if str(text or "").strip()
        },
        "facts": kept_facts,
    }


def _carries_notes(entry: dict[str, Any]) -> bool:
    """An entry with only the known tools and nothing found says nothing useful."""
    return bool(entry.get("extra_tools") or entry.get("facts") or entry.get("resources"))


def ledger_lines(entries: list[dict[str, Any]], *, current_challenge_id: str = "") -> list[str]:
    """Short lines for the prompt, newest first; empty when no entry carries notes."""
    lines: list[str] = []
    for entry in reversed(entries or []):
        if not isinstance(entry, dict) or not _carries_notes(entry):
            continue
        label = str(entry.get("challenge_id") or entry.get("puzzle_id") or "earlier challenge")
        kind = str(entry.get("challenge_type") or "").strip()
        head = f"{label} ({kind})" if kind else label
        if current_challenge_id and label == current_challenge_id:
            head = f"{head}, an earlier attempt at this same challenge"
        parts: list[str] = []
        extra_tools = [str(name) for name in entry.get("extra_tools") or []]
        if extra_tools:
            schemas = entry.get("tool_schemas") or {}
            rendered = []
            for name in extra_tools[:6]:
                summary = schemas.get(name) if isinstance(schemas, dict) else None
                if isinstance(summary, dict):
                    params = ", ".join(str(p) for p in summary.get("parameters") or [])
                    description = str(summary.get("description") or "").strip()
                    text = f"{name}({params})"
                    if description:
                        text = f"{text}: {description}"
                    rendered.append(text)
                else:
                    rendered.append(name)
            parts.append("tools beyond the known set: " + "; ".join(rendered))
        facts = [str(fact) for fact in entry.get("facts") or [] if str(fact).strip()]
        if facts:
            parts.append("statements found: " + " | ".join(facts[:MAX_FACTS]))
        resources = entry.get("resources") or {}
        if isinstance(resources, dict) and resources:
            parts.append(
                "resources: "
                + " | ".join(f"{uri}: {text}" for uri, text in list(resources.items())[:3])
            )
        line = f"{head}: " + "; ".join(parts)
        lines.append(line[:LINE_CHARS])
        if len(lines) >= MAX_LINES:
            break
    return lines
