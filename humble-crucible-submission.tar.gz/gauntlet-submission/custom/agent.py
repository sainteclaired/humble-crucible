#!/usr/bin/env python3
"""Custom Agent Gauntlet runtime.

A fork of `examples/python_simple/agent.py` (starter kit v1.2.3). The example
stays as shipped; this file is the team's runtime. Strategy tuning still lives
in `my_strategy.py`, which this runtime imports like the examples do.

Differences from the example:
- The challenge's `required_tools` are read for text and image runs, every tool
  call is recorded, and any required tool still missing is called before the
  solve (text) or the submit (image). A tool result carrying an `error` key
  does not count as a call.
- The tools are listed again after the challenge is fetched, and
  `arena.tools.list` is called when the server offers it; new agent_id-only
  tools are called once.
- Challenge fields the kit has no slot for (such as `output_format`), and tool
  results that add information, go into the solver prompt.
- `difficulty` reaches the strategy context, and the server's handshake
  `instructions` reach the prompt.
- When the server offers tools beyond the known set, or the challenge names a
  tool, the model explores them for a bounded time (`explore.py`) before the
  solve, on text and image challenges; plain encodings in clues and results
  are decoded as candidates, and statements found that way reach the strategy
  as `extra_facts` (the translator reads them).
- The solve call has a deadline that leaves time for one fallback model; a
  model that is still thinking at the deadline is cut off and the next ranked
  model gets the rest of the time.
- After submitting, a pending score is polled from the session for a bounded
  time, so the run record and the console show the final score.
- The MCP client reads every page of the tool list, keeps the handshake
  capabilities, reads advertised resources and prompt names (time-boxed),
  records notifications, and keeps every content block, `isError` and `_meta`
  of a tool result.
- Image challenges whose prompt asks a question about the input image run
  `image_analyze` first; text stored in the input image's metadata is read.

Usage:
    python custom/agent.py

Package with:
    python -m arena_clients.package --agent-id "$AGENT_ID" --agent-name "..." \
        --entrypoint custom/agent.py --include custom/explore.py

Loads `.env` from the repository root automatically.
"""

import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))
CUSTOM_DIR = Path(__file__).resolve().parent
if str(CUSTOM_DIR) not in sys.path:
    sys.path.insert(0, str(CUSTOM_DIR))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient as _KitMcpClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
from my_strategy import MyStrategy
from explore import (  # noqa: E402  (custom/explore.py)
    decoded_evidence,
    explore,
    facts_from_evidence,
    image_metadata_text,
    should_explore,
)

from mcp import ClientSession  # noqa: E402
from mcp.client.sse import sse_client  # noqa: E402


# Pages of a tool list the client will follow; the server decides page size.
MAX_LIST_PAGES = 20
# Time the handshake extras (resources, prompt names) may take in total.
DISCOVERY_EXTRAS_BUDGET_S = 2.0
MAX_RESOURCES_READ = 5
RESOURCE_TEXT_CHARS = 2000


class McpArenaClient(_KitMcpClient):
    """The kit's MCP client with the discovery the live server may need.

    Beyond the kit: the image challenge's raw payload is kept (the runtime
    needs its `required_tools`); the handshake's `instructions` and
    capabilities are kept; the tool list is read to its last page; advertised
    resources and prompt names can be read, time-boxed; server notifications
    are recorded; and a tool result keeps all of its content blocks, its
    `isError` flag and `_meta`, not only the first text block.
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._last_payload: dict = {}
        self.server_instructions = ""
        self.capabilities: dict[str, bool] = {}
        self.resource_texts: dict[str, str] = {}
        self.prompt_names: list[str] = []
        self.notifications: list[str] = []
        self.tools_changed = False

    async def _on_message(self, message) -> None:
        """Record what the server sends on its own; never raises."""
        try:
            root = getattr(message, "root", message)
            method = str(getattr(root, "method", "") or "")
            if method:
                self.notifications.append(method)
                if method.endswith("tools/list_changed"):
                    self.tools_changed = True
            elif isinstance(message, Exception):
                self.notifications.append(f"error: {type(message).__name__}")
        except Exception:
            pass

    async def __aenter__(self):
        # As the kit does, but keeping the handshake's instructions and capabilities.
        self._context = sse_client(self.sse_url, headers=self._headers)
        read, write = await self._context.__aenter__()
        self._session = ClientSession(read, write, message_handler=self._on_message)
        await self._session.__aenter__()
        init = await self._session.initialize()
        self.server_instructions = str(getattr(init, "instructions", "") or "").strip()
        capabilities = getattr(init, "capabilities", None)
        self.capabilities = {
            name: getattr(capabilities, name, None) is not None
            for name in ("tools", "resources", "prompts", "logging", "completions")
        }
        return self

    async def list_tool_defs(self) -> list:
        """Every page of the tool list (the kit reads page one)."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        tools: list = []
        cursor = None
        for _ in range(MAX_LIST_PAGES):
            result = await self._session.list_tools(cursor=cursor)
            tools.extend(result.tools)
            cursor = getattr(result, "nextCursor", None)
            if not cursor:
                break
        return tools

    async def list_tools(self) -> list[str]:
        return [tool.name for tool in await self.list_tool_defs()]

    async def discover_extras(self, budget_s: float = DISCOVERY_EXTRAS_BUDGET_S) -> list[str]:
        """Resources and prompt names the server advertises, as evidence lines.

        Only runs the requests the handshake capabilities announce, so a
        server without them (practice) costs nothing. Time-boxed as a whole.
        """
        lines: list[str] = []
        if not self._session:
            return lines
        deadline = time.monotonic() + budget_s

        def left() -> float:
            return max(0.1, deadline - time.monotonic())

        if self.capabilities.get("resources"):
            try:
                listed = await asyncio.wait_for(self._session.list_resources(), timeout=left())
            except Exception:
                listed = None
            for resource in list(getattr(listed, "resources", None) or [])[:MAX_RESOURCES_READ]:
                uri = str(getattr(resource, "uri", "") or "")
                if not uri or deadline - time.monotonic() <= 0:
                    break
                try:
                    read = await asyncio.wait_for(self._session.read_resource(resource.uri), timeout=left())
                except Exception:
                    continue
                texts = [str(getattr(item, "text", "") or "") for item in getattr(read, "contents", None) or []]
                text = "\n".join(part for part in texts if part).strip()
                if text:
                    self.resource_texts[uri] = text[:RESOURCE_TEXT_CHARS]
                    lines.append(f"resource {uri}: {text[:RESOURCE_TEXT_CHARS]}")
        if self.capabilities.get("prompts") and deadline - time.monotonic() > 0:
            try:
                listed = await asyncio.wait_for(self._session.list_prompts(), timeout=left())
                names = [str(getattr(prompt, "name", "") or "") for prompt in getattr(listed, "prompts", None) or []]
                self.prompt_names = [name for name in names if name]
                if self.prompt_names:
                    lines.append(f"prompts: {json.dumps(self.prompt_names)}")
            except Exception:
                pass
        return lines

    def _parse_result(self, result) -> dict:
        data = super()._parse_result(result)
        if isinstance(data, dict):
            data = _enrich_result(result, data)
        self._last_payload = data if isinstance(data, dict) else {}
        return data

    async def get_image_challenge(self, agent_id: str = "default"):
        challenge = await super().get_image_challenge(agent_id)
        challenge.raw_data = dict(self._last_payload)
        return challenge


def _enrich_result(result, data: dict) -> dict:
    """Add what the kit's parser drops: later blocks, links, images, isError, _meta.

    Keys are added only when present, so a practice result (one structured
    payload echoed as one text block) is unchanged.
    """
    structured = getattr(result, "structuredContent", None)
    blocks = list(getattr(result, "content", None) or [])
    texts: list[str] = []
    links: list[str] = []
    images: list[str] = []
    for index, block in enumerate(blocks):
        kind = str(getattr(block, "type", "") or "")
        if kind == "text":
            text = str(getattr(block, "text", "") or "")
            if index == 0:
                if structured is None:
                    continue  # the kit parsed this block
                try:
                    if json.loads(text) == structured:
                        continue  # the structured payload, echoed
                except ValueError:
                    pass
            if text.strip():
                texts.append(text)
        elif kind in {"resource_link", "resource"}:
            resource = getattr(block, "resource", None)
            uri = getattr(block, "uri", None) or getattr(resource, "uri", None)
            if uri:
                links.append(str(uri))
            embedded = getattr(resource, "text", None)
            if isinstance(embedded, str) and embedded.strip():
                texts.append(embedded)
        elif kind == "image":
            mime = str(getattr(block, "mimeType", "") or "image/png")
            payload = str(getattr(block, "data", "") or "")
            if payload:
                images.append(f"data:{mime};base64,{payload}")
    if texts:
        data.setdefault("_text", texts)
    if links:
        data.setdefault("_links", links)
    if images:
        data.setdefault("_images", images)
    if getattr(result, "isError", False) and not data.get("error"):
        data["error"] = texts[0] if texts else str(data.get("raw") or "tool error")
    meta = getattr(result, "meta", None)
    if meta:
        data.setdefault("_meta", meta)
    return data


@dataclass
class RuntimeContext(ChallengeContext):
    """The kit's context plus what this runtime learned from the server.

    Hooks that take a `ChallengeContext` get one of these; `extra_facts` are
    short statements from tool results and decodings (the translator in
    `my_strategy.py` reads them), `evidence` is every evidence line.
    """

    evidence: list[str] = field(default_factory=list)
    extra_facts: list[str] = field(default_factory=list)
    server_instructions: str = ""


# Use OpenAI SDK for LLM calls through the proxy.
try:
    from openai import OpenAI

    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()

    # Accept either "ANSWER:" or "Final answer:" on its own line.
    for line in cleaned.splitlines():
        match = re.match(
            r"^\s*(?:answer|final answer)\s*:\s*(.+?)\s*$",
            line,
            flags=re.IGNORECASE,
        )
        if match:
            answer = match.group(1).strip().strip("`\"'")
            if answer:
                return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> list[str]:
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    required: list[str] = []
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in blob:
            required.append(normalized)
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower() and normalized not in required:
                required.append(normalized)
    return required


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    return any(token in lowered for token in blocked_tokens)


# Seconds a follow-up model call (evidence answer, strict format retry) needs.
MIN_FOLLOW_UP_S = 3.0


def _is_timeout_error(exc: BaseException) -> bool:
    name = type(exc).__name__.lower()
    text = str(exc).lower()
    return "timeout" in name or "timed out" in text or "timeout" in text


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
    timeout_s: float | None = None,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    options = {} if timeout_s is None else {"timeout": max(1.0, float(timeout_s))}
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only the final answer line."
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
            **options,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    http_client: HttpArenaClient,
    extra_context: str = "",
    called_tools: set[str] | None = None,
) -> list[str]:
    required_runtime_tools = _required_runtime_tools(
        available_tool_names,
        challenge_type=challenge_type,
        description=description,
        rules=rules,
        extra_context=extra_context,
    )
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    for tool_name in required_runtime_tools:
        if called_tools is not None and tool_name in called_tools:
            continue
        is_search_like = "search" in tool_name.lower()
        target_calls = min(len(queries), 3) if is_search_like else 1
        calls_made = 0
        for query in queries[:target_calls]:
            payload_variants = [
                {"agent_id": agent_id, "query": query},
                {"query": query},
                {"agent_id": agent_id, "search_query": query},
                {"search_query": query},
                {"agent_id": agent_id, "text": query},
                {"text": query},
                {"agent_id": agent_id, "url": query},
                {"url": query},
                {"agent_id": agent_id, "video_url": query},
                {"video_url": query},
                {"agent_id": agent_id},
                {},
            ]
            for payload in payload_variants:
                try:
                    result = await mcp_client.call_tool(tool_name, payload)
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                    calls_made += 1
                    if called_tools is not None and not _result_error(result):
                        called_tools.add(tool_name)
                    break
                except Exception:
                    continue
        status_note = (
            f"Required tool coverage: {tool_name} ({calls_made}/{target_calls})"
            if target_calls > 1
            else f"Required tool called: {tool_name}"
            if calls_made
            else f"Could not call required tool: {tool_name}"
        )
        try:
            http_client.broadcast_thought(agent_id, status_note)
        except Exception:
            pass
    return evidence_lines


def _result_error(result: object) -> str:
    """The error text of a tool result that failed inside the tool, else ""."""
    if isinstance(result, dict) and result.get("error"):
        return str(result["error"])
    return ""


async def _rediscover_tools(
    mcp_client: McpArenaClient,
    agent_id: str,
    known_names: list[str],
    known_defs: list,
    called_tools: set[str],
) -> tuple[list[str], list, list[str], list[str]]:
    """List the tools again, and ask `arena.tools.list` when the server has it.

    The server may register tools after the challenge is fetched and does not
    announce them. Returns (names, defs, names not in known_names, evidence).
    """
    names = list(known_names)
    defs = list(known_defs)
    evidence: list[str] = []
    try:
        fresh = await mcp_client.list_tool_defs()
    except Exception:
        fresh = []
    if fresh:
        defs = list(fresh)
        names = [str(getattr(tool_def, "name", "") or "") for tool_def in fresh]
        names = [name for name in names if name]
    if "arena.tools.list" in names:
        try:
            listed = await mcp_client.call_tool("arena.tools.list", {"agent_id": agent_id})
        except Exception:
            listed = None
        if isinstance(listed, dict) and not _result_error(listed):
            called_tools.add("arena.tools.list")
            rendered = _tool_result_text(listed)
            if rendered:
                evidence.append(f"arena.tools.list: {rendered[:2000]}")
            for name in listed.get("tools") or []:
                name = str(name or "").strip()
                if name and name not in names:
                    names.append(name)
    new_names = [name for name in names if name not in known_names]
    return names, defs, new_names, evidence


async def _call_new_getters(
    mcp_client: McpArenaClient,
    agent_id: str,
    new_names: list[str],
    tool_defs: list,
    called_tools: set[str],
) -> list[str]:
    """Call once each newly listed tool that needs nothing beyond agent_id."""
    defs = {str(getattr(tool_def, "name", "")): tool_def for tool_def in tool_defs}
    evidence: list[str] = []
    for name in new_names:
        tool_def = defs.get(name)
        if tool_def is None or _is_submit_tool(name) or name in called_tools:
            continue
        arguments = _required_tool_arguments(tool_def, {"agent_id": agent_id})
        if arguments is None:
            continue
        try:
            result = await mcp_client.call_tool(name, arguments)
        except Exception:
            continue
        if not _result_error(result):
            called_tools.add(name)
        rendered = _tool_result_text(result)
        if rendered:
            evidence.append(f"{name}: {rendered[:2000]}")
    return evidence


def _required_tools_from(raw: object) -> list[str]:
    """The challenge payload's `required_tools`, in order, without duplicates."""
    value = raw.get("required_tools") if isinstance(raw, dict) else None
    if not isinstance(value, list):
        return []
    names: list[str] = []
    for item in value:
        name = str(item or "").strip()
        if name and name not in names:
            names.append(name)
    return names


def _is_submit_tool(name: str) -> bool:
    return "submit" in name.lower()


def _required_tool_arguments(tool_def: object, known: dict[str, object]) -> dict | None:
    """Fill a tool's parameters from known values; None if a required one has no value."""
    schema = getattr(tool_def, "inputSchema", None) or {}
    properties = schema.get("properties") or {}
    required = set(schema.get("required") or [])
    arguments: dict[str, object] = {}
    for param in properties:
        value = known.get(param)
        if value not in (None, ""):
            arguments[param] = value
        elif param in required:
            return None
    return arguments


def _required_image_tool_sequence(
    sequence: list[str],
    required: list[str],
    image_tools: list[str],
    *,
    has_input_image: bool,
) -> list[str]:
    """Make the image plan use the output and analysis tools the challenge requires."""
    sequence = list(sequence)
    for output_tool in ("image_edit", "image_generate"):
        if output_tool not in required or output_tool not in image_tools:
            continue
        if output_tool == "image_edit" and not has_input_image:
            continue
        if sequence and sequence[-1] in {"image_edit", "image_generate"}:
            sequence[-1] = output_tool
        else:
            sequence.append(output_tool)
        break
    if (
        "image_analyze" in required
        and "image_analyze" in image_tools
        and has_input_image
        and "image_analyze" not in sequence
        and sequence
    ):
        sequence.insert(0, "image_analyze")
    return sequence


async def _call_missing_required_tools(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    required: list[str],
    called_tools: set[str],
    tool_defs: list,
    known_arguments: dict[str, object],
    http_client: HttpArenaClient,
    extra_arguments: dict[str, dict[str, str]] | None = None,
) -> list[str]:
    """Call each required tool the run has not called yet; returns evidence lines.

    Skipping a required tool sets quality to 0, so this runs whatever the main
    path did. Submit tools are left to the submit step.
    """
    defs = {str(getattr(tool_def, "name", "")): tool_def for tool_def in tool_defs}
    evidence_lines: list[str] = []
    for name in required:
        if name in called_tools or _is_submit_tool(name):
            continue
        tool_def = defs.get(name)
        if tool_def is None:
            arguments: dict | None = {"agent_id": agent_id}
        else:
            arguments = _required_tool_arguments(tool_def, known_arguments)
        if arguments is None:
            note = f"Could not call required tool {name}: a required parameter has no value"
        else:
            arguments.update((extra_arguments or {}).get(name, {}))
            try:
                result = await mcp_client.call_tool(name, arguments)
            except Exception as exc:
                note = f"Could not call required tool {name} ({type(exc).__name__})"
            else:
                rendered = _tool_result_text(result)
                if rendered:
                    evidence_lines.append(f"{name}: {rendered[:2000]}")
                if _result_error(result):
                    # The server does not count a call that failed inside the tool.
                    note = f"Required tool {name} returned an error: {_result_error(result)[:160]}"
                else:
                    called_tools.add(name)
                    note = f"Required tool called: {name}"
        print(f"   {note}")
        try:
            http_client.broadcast_thought(agent_id, note)
        except Exception:
            pass
    return evidence_lines


def _warn_missing_required_tools(required: list[str], called_tools: set[str]) -> None:
    missing = [name for name in required if name not in called_tools]
    if missing:
        print(f"   ⚠️  Required tools not called over MCP (quality may be 0): {', '.join(missing)}")


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    image_url: str | None = None,
    required_tools: list[str] | None = None,
    difficulty: str = "unknown",
    evidence: list[str] | None = None,
    extra_facts: list[str] | None = None,
    server_instructions: str = "",
) -> RuntimeContext:
    return RuntimeContext(
        challenge_type=challenge_type,
        difficulty=str(difficulty or "unknown"),
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=list(required_tools or []),
        image_url=image_url,
        evidence=list(evidence or []),
        extra_facts=list(extra_facts or []),
        server_instructions=str(server_instructions or ""),
    )


# --- time budgets ------------------------------------------------------------

# Time kept back from the solve for the time check, hooks and the submit.
RESERVE_SHARE = 0.15
RESERVE_MIN_S = 6.0
RESERVE_MAX_S = 20.0
# The first model's share of the usable time; the rest is for one fallback.
FIRST_MODEL_SHARE = 0.70
FIRST_MODEL_MIN_S = 10.0
# A fallback model needs at least this long to be worth calling.
MIN_RETRY_BUDGET_S = 8.0


def _reserve_s(max_time_s: float) -> float:
    return max(RESERVE_MIN_S, min(RESERVE_MAX_S, float(max_time_s) * RESERVE_SHARE))


def _solve_budgets(max_time_s: float, remaining_s: float) -> tuple[float | None, float]:
    """(first model's deadline in seconds, seconds left for a fallback).

    With no time limit there is no deadline. Otherwise the first model gets
    FIRST_MODEL_SHARE of what remains after the reserve, so a model that
    hangs still leaves time for another.
    """
    if not max_time_s or max_time_s <= 0:
        return None, 0.0
    usable = max(0.0, float(remaining_s) - _reserve_s(max_time_s))
    first = min(usable, max(FIRST_MODEL_MIN_S, usable * FIRST_MODEL_SHARE))
    return first, max(0.0, usable - first)


# --- score polling -----------------------------------------------------------

SCORE_POLL_INTERVAL_S = 2.0
# Statuses under which a missing score is still coming.
_PENDING_STATUSES = frozenset({"submitted", "pending", "pending_evaluation", "evaluating", "judging"})
_TERMINAL_STATUSES = frozenset({"stopped", "failed", "error", "disconnected"})


def _score_poll_timeout_s() -> float:
    try:
        return max(0.0, float(os.getenv("ARENA_SCORE_POLL_S", "30")))
    except ValueError:
        return 30.0


def _score_is_pending(score: object, status: object) -> bool:
    """Whether the submit response's score is a placeholder (judge still running)."""
    if isinstance(score, dict) and score:
        return bool(score.get("pending_evaluation")) or score.get("final_score") is None
    return str(status or "").strip().lower() in _PENDING_STATUSES


async def _await_final_score(
    http_client,
    agent_id: str,
    *,
    timeout_s: float | None = None,
    interval_s: float | None = None,
) -> dict | None:
    """Poll the session until its score is final, or the time is up; never raises."""
    timeout_s = _score_poll_timeout_s() if timeout_s is None else timeout_s
    interval_s = SCORE_POLL_INTERVAL_S if interval_s is None else interval_s
    if timeout_s <= 0:
        return None
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            session = await asyncio.to_thread(http_client.get_session, agent_id)
        except Exception:
            session = None
        score = session.get("score") if isinstance(session, dict) else None
        status = str(session.get("status") or "").lower() if isinstance(session, dict) else ""
        if isinstance(score, dict) and score.get("final_score") is not None and not score.get("pending_evaluation"):
            return score
        if status in _TERMINAL_STATUSES or time.monotonic() >= deadline:
            return score if isinstance(score, dict) and score else None
        await asyncio.sleep(max(0.0, min(interval_s, deadline - time.monotonic())))


async def _report_final_score(http_client, agent_id: str, score: object, status: object) -> tuple[dict | None, str]:
    """(score, source): the submit response's score, or the session's once it is final."""
    final = score if isinstance(score, dict) else None
    if not _score_is_pending(score, status):
        return final, "submit"
    print("   Score pending; polling the session...")
    polled = await _await_final_score(http_client, agent_id)
    if polled:
        print(f"   Final score: {polled.get('final_score')} (quality {polled.get('quality_score')}, speed {polled.get('speed_score')})")
        return polled, "session"
    print("   Score still pending when the poll ended; the session will carry it.")
    return final, "submit"


# --- image challenges --------------------------------------------------------

# Prompt wording that asks about the input image rather than for an edit.
_IMAGE_QUESTION_MARKERS = (
    "?", "what ", "which ", "how many", "count the", "identify", "describe", "analy",
    "anomal", "pattern", "hidden", "decode", "detect", "spot the", "odd one", "difference",
    "is written", "the message", "the number", "the code", "the word",
)


def _image_question(prompt_text: str, notes: str = "") -> str:
    """The marker that makes the prompt a question about the input image, or ""."""
    blob = f"{prompt_text or ''}\n{notes or ''}".lower()
    for marker in _IMAGE_QUESTION_MARKERS:
        if marker in blob:
            return marker.strip()
    return ""


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# Why a solve ended without an answer and another model should try.
RETRY_FINISH_REASONS = frozenset({"length", "deadline"})


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


async def _retry_with_next_model(result, *, ranked_models, remaining_s, solve_with, max_time_s=0):
    """Retry once with the next ranked model when the first gave no answer.

    ``result`` is solve_challenge's tuple. Two stops qualify: "length" (a
    reasoning model spent its whole token budget thinking; asking it again
    would do the same) and "deadline" (it was still thinking when its time
    ran out). The next model gets what is left minus the reserve, as its own
    deadline, when that is at least MIN_RETRY_BUDGET_S. Token usage and time
    add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    reason = str(usage.get("finish_reason") or "")
    if answer or reason not in RETRY_FINISH_REASONS:
        return result
    if reason == "length":
        tokens_spent = int(usage.get("completion_tokens", 0) or 0)
        print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    else:
        print(f"   ⚠️  {model_name} was still thinking at its deadline and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    budget_s = left_s - _reserve_s(max_time_s) if max_time_s else left_s
    if not retry_model or budget_s < MIN_RETRY_BUDGET_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model} ({budget_s:.0f}s). Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model, budget_s if max_time_s else None)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


# Challenge keys the solver prompt already shows, or that only identify or time the run.
_PROMPT_OR_BOOKKEEPING_KEYS = frozenset(
    {
        "challenge_type",
        "challenge_id",
        "puzzle_id",
        "difficulty",
        "description",
        "rules",
        "clues",
        "max_time_s",
        "time_remaining_s",
        "required_tools",
    }
)


def _extra_challenge_fields(raw: object, prompt: str) -> list[str]:
    """Challenge fields the prompt does not show yet, as `- key: value` lines.

    Covers fields the kit has no slot for, such as `output_format`, and any
    the server adds later.
    """
    if not isinstance(raw, dict):
        return []
    lines: list[str] = []
    for key, value in raw.items():
        if key in _PROMPT_OR_BOOKKEEPING_KEYS or value in (None, "", [], {}):
            continue
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        if text.startswith("data:"):
            text = "(inline data omitted)"
        text = text.strip()[:2000]
        if text and text not in prompt:
            lines.append(f"- {key}: {text}")
    return lines


# Result keys that time or count the call rather than describe the puzzle.
_RESULT_BOOKKEEPING_KEYS = frozenset(
    {
        "agent_id",
        "accepted",
        "clue_id",
        "clue_ids",
        "count",
        "elapsed_s",
        "expired",
        "max_time_s",
        "time_remaining_s",
        "tools",
        "_images",
    }
)
_TOOL_RESULT_LINE_CHARS = 1500
_TOOL_RESULT_SECTION_CHARS = 4000


def _novel_tool_results(evidence_lines: list[str] | None, prompt: str) -> list[str]:
    """Tool results reduced to what the prompt does not already say.

    Each line is `tool: <json or text>`. Values already in the prompt (clue
    texts, the tool list) and bookkeeping keys are dropped; an error is kept
    as its own line, since servers put hints there.
    """
    lines: list[str] = []
    used = 0
    for line in evidence_lines or []:
        name, sep, body = line.partition(": ")
        if not sep or not body.strip():
            continue
        try:
            data: object = json.loads(body)
        except ValueError:
            data = body
        if isinstance(data, dict):
            error = _result_error(data)
            if error:
                rendered = f"- {name} returned an error: {error[:300]}"
            else:
                kept: dict[str, object] = {}
                for key, value in data.items():
                    if key in _RESULT_BOOKKEEPING_KEYS or value in (None, "", [], {}):
                        continue
                    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
                    if text.strip() and text not in prompt:
                        kept[key] = value
                if not kept:
                    continue
                rendered = f"- {name}: {json.dumps(kept, ensure_ascii=False)[:_TOOL_RESULT_LINE_CHARS]}"
        else:
            text = str(data).strip()
            if not text or text in prompt:
                continue
            rendered = f"- {name}: {text[:_TOOL_RESULT_LINE_CHARS]}"
        if used + len(rendered) > _TOOL_RESULT_SECTION_CHARS:
            break
        lines.append(rendered)
        used += len(rendered)
    return lines


def build_runtime_prompt(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    raw_challenge: object = None,
    evidence_lines: list[str] | None = None,
) -> str:
    """The user prompt sent to the solver: strategy prompt, other fields, tool results, guardrails."""
    prompt = strategy.build_solver_prompt(ctx)
    extra = _extra_challenge_fields(raw_challenge, prompt)
    if extra:
        prompt = f"{prompt}\n\nOther challenge fields:\n" + "\n".join(extra)
    novel = _novel_tool_results(evidence_lines, prompt)
    if novel:
        prompt = (
            f"{prompt}\n\nTool results from the server (may or may not matter; "
            "check them against the clues):\n" + "\n".join(novel)
        )
    return (
        f"{prompt}\n\n"
        "Output guardrails:\n"
        "- Return only your final answer line.\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
    deadline_s: float | None = None,
):
    """Solve the challenge using the selected LLM model.

    When http_client and agent_id are provided, streams reasoning to Agent Gauntlet in real time.
    With ``deadline_s``, the model is cut off that many seconds from now; the
    result then carries finish_reason "deadline" and whatever was streamed.

    Returns:
        tuple: (extracted_answer, raw_response, model_name, usage_dict, ttft_ms, total_time_ms)
    """

    _ = clues
    # The clock starts before the prompt is built: a strategy hook that calls
    # a model (the translator) spends part of the first model's budget.
    deadline = time.monotonic() + float(deadline_s) if deadline_s else None
    prompt = build_runtime_prompt(strategy, ctx, getattr(challenge, "raw_data", None), evidence_lines)
    system_msg = strategy.build_system_prompt(ctx)
    llm_params = strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))

    def _left() -> float | None:
        return None if deadline is None else max(0.0, deadline - time.monotonic())

    def _request_timeout() -> dict:
        # The HTTP read timeout catches a stream that sends nothing at all.
        left = _left()
        return {} if left is None else {"timeout": max(1.0, left)}

    timed_out = False

    # Track timing
    start_ms = time.time() * 1000
    ttft_ms = 0
    raw_content_parts = []
    # Kept apart so the answer comes from the final reply, as in the
    # non-streaming path; reasoning can hold draft "ANSWER:" lines.
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []
    pending_broadcast = ""
    _BROADCAST_CHUNK = 80  # chars before sending a thought

    def _flush_broadcast(force: bool = False) -> None:
        nonlocal pending_broadcast
        if not http_client or not agent_id or not broadcast_thought:
            return
        if force or len(pending_broadcast) >= _BROADCAST_CHUNK or "\n" in pending_broadcast:
            chunk = pending_broadcast.strip()
            pending_broadcast = ""
            if chunk:
                try:
                    http_client.broadcast_thought(agent_id, chunk[:300])
                except Exception:
                    pass

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""
    if stream_enabled and http_client and agent_id:
        # Stream and broadcast in real time
        try:
            stream = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
                **_request_timeout(),
            )
            header_sent = False
            for chunk in stream:
                if deadline is not None and time.monotonic() > deadline:
                    timed_out = True
                    try:
                        stream.close()
                    except Exception:
                        pass
                    break
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                        raw_content_parts.append(text)
                        if broadcast_thought:
                            if not header_sent:
                                http_client.broadcast_thought(agent_id, "💭 LLM Reasoning:")
                                header_sent = True
                            pending_broadcast += text
                            _flush_broadcast()
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
            _flush_broadcast(force=True)
        except Exception as e:
            if _is_timeout_error(e) or (deadline is not None and _left() <= 0.5):
                timed_out = True  # keep what was streamed; no second call
                _flush_broadcast(force=True)
            elif "stream" in str(e).lower() or "Stream" in str(e):
                stream_enabled = False
                raw_content_parts = []  # Fall through to non-streaming
            else:
                raise

    if timed_out:
        finish_reason = "deadline"
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)
    elif not stream_enabled or not raw_content_parts:
        # Non-streaming fallback
        try:
            response = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                **_request_timeout(),
            )
        except Exception as e:
            if not _is_timeout_error(e):
                raise
            timed_out = True
            response = None
        if response is None:
            raw_content = ""
            finish_reason = "deadline"
        else:
            raw_content = response.choices[0].message.content or ""
            finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
            usage = response.usage
            ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)
    else:
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer = extract_answer(raw_content)
    if _is_invalid_answer_candidate(answer):
        answer = ""
    # Follow-up calls need time of their own; past the deadline the caller
    # moves on to the next model instead.
    follow_up_ok = _left() is None or _left() >= MIN_FOLLOW_UP_S
    if not answer and evidence_lines and follow_up_ok:
        answer = _derive_answer_from_evidence(
            llm_client=llm_client,
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
            timeout_s=_left(),
        )
        if _is_invalid_answer_candidate(answer):
            answer = ""
    # A model that ran out of tokens while thinking would only do it again;
    # the caller retries with another model instead.
    if not answer and finish_reason not in RETRY_FINISH_REASONS and follow_up_ok:
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=min(temperature, 0.0),
                stream=False,
                **_request_timeout(),
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
        except Exception:
            pass
    if _is_invalid_answer_candidate(answer):
        answer = ""

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    # Streams usually carry no usage; estimate from everything streamed,
    # reasoning included, not only the reply the answer was read from.
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2  # rough estimate
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


async def main():
    """Main agent loop."""
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "custom-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Team Nova"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # Step 1: Register with Agent Gauntlet
    print("📝 Registering with Agent Gauntlet...")
    session = http_client.register(agent_id, agent_name)
    print(f"   Session: {session.session_id}")
    print(f"   Status: {session.status}")
    session_monitor = monitor_session(http_client, agent_id).start()
    
    # Step 2: Get challenge from MCP
    print("\n🎯 Getting challenge...")
    async with McpArenaClient(mcp_url) as mcp_client:
        tools = await mcp_client.list_tools()
        tool_defs = await mcp_client.list_tool_defs()
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        image_tool_proxy_args: dict[str, dict[str, str]] = {}
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.to_thread(
                    _fetch_proxy_usage,
                    llm_host,
                    llm_api_key,
                    agent_id,
                    usage_scope,
                )
            except Exception:
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                await asyncio.to_thread(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                )
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            await _push_live_status("running")
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            reporter_stop.set()
            if metrics_task is not None:
                try:
                    await asyncio.wait_for(metrics_task, timeout=2.0)
                except Exception:
                    if not metrics_task.done():
                        metrics_task.cancel()
            await _push_live_status("running")

        if modality == "image":
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise
            print_challenge(challenge)
            called_tools: set[str] = {"arena.image.get_challenge"}
            required_tools = _required_tools_from(getattr(challenge, "raw_data", None))
            tools, tool_defs, new_tools, image_evidence_lines = await _rediscover_tools(
                mcp_client, agent_id, [str(name) for name in tools], tool_defs, called_tools
            )
            if new_tools:
                print(f"   Tools listed after the challenge was fetched: {new_tools}")
            discover_extras = getattr(mcp_client, "discover_extras", None)
            if discover_extras is not None:
                image_evidence_lines += await discover_extras()
            usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            # Text stored inside the input image (comments, EXIF, XMP) is
            # where an image puzzle can hide its instructions.
            metadata_lines = image_metadata_text(challenge.input_image_uri or "")
            if metadata_lines:
                print(f"   Input image metadata: {metadata_lines[:3]}")
                http_client.broadcast_thought(agent_id, f"Input image metadata: {' | '.join(metadata_lines)[:200]}")
                image_evidence_lines.append(f"image_metadata: {json.dumps(metadata_lines, ensure_ascii=False)}")
                image_evidence_lines += decoded_evidence(
                    {f"image_metadata_{index}": line for index, line in enumerate(metadata_lines)}
                )

            available_models = fetch_available_models(llm_host, llm_api_key)
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                difficulty=str(getattr(challenge, "difficulty", "") or "unknown"),
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
                required_tools=required_tools,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="custom agent",
            )
            image_tool_proxy_args = {
                tool_name: build_image_tool_arguments(
                    tool_defs,
                    tool_name,
                    selected_model=model_name,
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            print(f"   Selected model: {model_name}")
            http_client.broadcast_thought(agent_id, f"Selected planner model: {model_name}")
            await _start_metrics_reporter(model_name)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt

            # Exploration, as on text: only when the server offers tools beyond
            # the known set or the challenge names one. A text model drives
            # it; the findings are added to the image prompt.
            image_text = "\n".join(
                str(part)
                for part in (challenge.description, challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            exploration_reason = should_explore([str(name) for name in tools], image_text)
            explorer_models = strategy.rank_models(
                _build_context(
                    challenge_type="text",
                    description=challenge.description,
                    rules=image_rules,
                    max_time_s=challenge.max_time_s,
                    available_models=available_models,
                ),
                available_models,
            )
            if exploration_reason and explorer_models:
                explorer_model = explorer_models[0]
                print(f"   Exploring the server with {explorer_model} ({exploration_reason})")
                http_client.broadcast_thought(agent_id, f"Exploring the server: {exploration_reason}")
                explorer_client = OpenAI(
                    base_url=llm_host,
                    api_key=llm_api_key,
                    default_headers=build_proxy_headers(agent_id, usage_scope),
                )
                exploration = await explore(
                    llm_client=explorer_client,
                    model=explorer_model,
                    tool_defs=tool_defs,
                    call_tool=mcp_client.call_tool,
                    list_tool_defs=mcp_client.list_tool_defs,
                    agent_id=agent_id,
                    challenge_text=image_text,
                    clues=list(metadata_lines),
                    evidence_lines=image_evidence_lines,
                    strategy=strategy,
                    ctx=image_ctx,
                    max_time_s=int(challenge.max_time_s or 0),
                    modality="image",
                    on_event=lambda note: http_client.broadcast_thought(agent_id, note),
                )
                image_evidence_lines += exploration.evidence
                called_tools.update(exploration.called)
                image_evidence_lines += decoded_evidence(
                    {f"result_{index}": line for index, line in enumerate(exploration.evidence)}
                )
                print(
                    f"   Exploration: {len(exploration.called)} tool calls, "
                    f"{exploration.llm_calls} model turns, stopped by {exploration.stopped}"
                )
            image_facts = facts_from_evidence(image_evidence_lines, [prompt_text, image_text])
            if image_facts:
                print(f"   Statements found on the server: {image_facts[:3]}")
                prompt_text = (
                    f"{prompt_text}\n\nAdditional instructions found on the server: "
                    + " ".join(image_facts[:3])[:600]
                )

            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            image_tool_sequence = _required_image_tool_sequence(
                _plan_image_tool_sequence(strategy, image_ctx, image_tools),
                required_tools,
                image_tools,
                has_input_image=bool(challenge.input_image_uri),
            )
            question = _image_question(image_prompt, str(challenge.reference_notes or ""))
            if (
                question
                and challenge.input_image_uri
                and "image_analyze" in image_tools
                and image_tool_sequence
                and "image_analyze" not in image_tool_sequence
            ):
                # The prompt asks about the picture; look at it before drawing.
                print(f"   The prompt asks about the input image ({question!r}); analyzing it first")
                image_tool_sequence.insert(0, "image_analyze")
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            async def _call_image_tool(name: str, arguments: dict) -> dict:
                nonlocal mcp_session_dead
                try:
                    result = await mcp_client.call_tool(name, arguments)
                    if not _result_error(result):
                        called_tools.add(name)
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {}

            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                print("   Using image_edit tool")
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                print("   Using image_generate tool")
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
            elif challenge.input_image_uri and "image_edit" in image_tools:
                selected_tool = "image_edit"
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif "image_generate" in image_tools:
                selected_tool = "image_generate"
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )

            if tool_result.get("error"):
                print(f"   Tool warning: {tool_result.get('error')}")

            output_image_uri = str(tool_result.get("image_uri") or "").strip()
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                if mcp_session_dead:
                    await session_monitor.stop()
                    raise RuntimeError(
                        "Image MCP tool failed and no input_image_uri is available "
                        "to submit; refusing to invent image bytes"
                    )
                output_image_uri = BLANK_PNG_DATA_URI

            if not mcp_session_dead:
                await _call_missing_required_tools(
                    mcp_client=mcp_client,
                    agent_id=agent_id,
                    required=required_tools,
                    called_tools=called_tools,
                    tool_defs=tool_defs,
                    known_arguments={
                        "agent_id": agent_id,
                        "image_uri": challenge.input_image_uri or output_image_uri,
                        "prompt": prompt_text,
                        "question": prompt_text,
                    },
                    http_client=http_client,
                    extra_arguments=image_tool_proxy_args,
                )

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            client_metrics = {
                "model_name": model_name,
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = http_client.submit(
                    agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                )
            else:
                image_submit_result = await mcp_client.submit_image(
                    agent_id=agent_id,
                    image_uri=output_image_uri,
                    client_metrics=client_metrics,
                    rationale="custom runtime image flow",
                )
                called_tools.add("arena.image.submit_edit")
            _warn_missing_required_tools(required_tools, called_tools)
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            # Last steps, after the submission is final; neither raises.
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:  # REST fallback returns a SubmitResult
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            status = image_result.get("status") or getattr(image_submit_result, "status", None)
            final_score, score_source = await _report_final_score(http_client, agent_id, score or None, status)
            if final_score:
                score = final_score
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "evidence": image_evidence_lines,
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                    "score_source": score_source,
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            print("\n✅ Agent completed!")
            return

        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while True:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    raise
        print_challenge(challenge)
        challenge_fetched_at = time.monotonic()
        called_tools: set[str] = {"arena.get_challenge"}
        required_tools = _required_tools_from(getattr(challenge, "raw_data", None))
        instructions = str(getattr(mcp_client, "server_instructions", "") or "")
        if instructions and isinstance(getattr(challenge, "raw_data", None), dict):
            challenge.raw_data.setdefault("server_instructions", instructions)
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        llm_client = OpenAI(
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )
        print("   LLM: Enabled")
        print()

        available_models = fetch_available_models(llm_host, llm_api_key)
        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=str(getattr(challenge, "difficulty", "") or "unknown"),
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="custom agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)
        
        # Broadcast thought
        http_client.broadcast_thought(agent_id, "Reading challenge and clues...")
        
        # Get all clues
        print("\n📖 Reading clues...")
        clues = []
        clue_ids = await mcp_client.list_clues(agent_id)
        called_tools.add("arena.clues.list")
        for i, clue_id in enumerate(clue_ids):
            clue = await mcp_client.get_clue(clue_id, agent_id)
            called_tools.add("arena.clues.get")
            clues.append(clue.text)
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues]

        tools, tool_defs, new_tools, tool_evidence_lines = await _rediscover_tools(
            mcp_client, agent_id, [str(name) for name in tools], tool_defs, called_tools
        )
        if new_tools:
            print(f"   Tools listed after the challenge was fetched: {new_tools}")
            http_client.broadcast_thought(agent_id, f"New tools: {', '.join(new_tools)}")
            tool_evidence_lines += await _call_new_getters(
                mcp_client, agent_id, new_tools, tool_defs, called_tools
            )
        discover_extras = getattr(mcp_client, "discover_extras", None)
        if discover_extras is not None:
            tool_evidence_lines += await discover_extras()

        tool_evidence_lines += await _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
            called_tools=called_tools,
        )
        tool_evidence_lines += await _call_missing_required_tools(
            mcp_client=mcp_client,
            agent_id=agent_id,
            required=required_tools,
            called_tools=called_tools,
            tool_defs=tool_defs,
            known_arguments={
                "agent_id": agent_id,
                "clue_id": str(clue_ids[0]) if clue_ids else None,
            },
            http_client=http_client,
        )

        # Exploration: only when the server offers tools beyond the known set,
        # or the challenge names one. Practice puzzles take the single-call path.
        challenge_text = "\n".join(
            str(part) for part in (challenge.description, challenge.rules) if part
        )
        exploration_reason = should_explore([str(name) for name in tools], challenge_text)
        if exploration_reason:
            print(f"   Exploring the server ({exploration_reason})")
            http_client.broadcast_thought(agent_id, f"Exploring the server: {exploration_reason}")
            exploration = await explore(
                llm_client=llm_client,
                model=model_name,
                tool_defs=tool_defs,
                call_tool=mcp_client.call_tool,
                list_tool_defs=mcp_client.list_tool_defs,
                agent_id=agent_id,
                challenge_text=challenge_text,
                clues=clues,
                evidence_lines=tool_evidence_lines,
                strategy=strategy,
                ctx=model_ctx,
                max_time_s=int(challenge.max_time_s or 0),
                on_event=lambda note: http_client.broadcast_thought(agent_id, note),
            )
            tool_evidence_lines += exploration.evidence
            if exploration.summary:
                tool_evidence_lines.append(f"exploration: {exploration.summary[:1000]}")
            called_tools.update(exploration.called)
            print(
                f"   Exploration: {len(exploration.called)} tool calls, "
                f"{exploration.llm_calls} model turns, stopped by {exploration.stopped}"
            )
        decode_sources = {"challenge": challenge_text}
        decode_sources.update({f"clue_{index}": clue for index, clue in enumerate(clues)})
        decode_sources.update({f"result_{index}": line for index, line in enumerate(tool_evidence_lines)})
        tool_evidence_lines += decoded_evidence(decode_sources)
        if getattr(mcp_client, "tools_changed", False):
            # The server announced a change to its tool list; look again.
            mcp_client.tools_changed = False
            tools, tool_defs, late_tools, late_evidence = await _rediscover_tools(
                mcp_client, agent_id, [str(name) for name in tools], tool_defs, called_tools
            )
            tool_evidence_lines += late_evidence
            if late_tools:
                print(f"   Tools added by the server: {late_tools}")
                tool_evidence_lines += await _call_new_getters(
                    mcp_client, agent_id, late_tools, tool_defs, called_tools
                )
        # Short statements from tool results and decodings: the strategy's
        # translator reads them as optional extra clues.
        extra_facts = facts_from_evidence(
            tool_evidence_lines, [*clues, str(challenge.description or ""), str(challenge.rules or "")]
        )
        if extra_facts:
            print(f"   Statements found on the server: {len(extra_facts)}")
            http_client.broadcast_thought(agent_id, f"Found {len(extra_facts)} statement(s) on the server")

        # Broadcast thought
        http_client.broadcast_thought(agent_id, f"Analyzing {len(clues)} clues...")
        
        # Save draft (backup)
        http_client.save_draft(agent_id, "Working on solution...")
        
        # Step 3: Solve
        print("\n🧠 Solving...")
        http_client.broadcast_thought(agent_id, "Calling LLM...")
        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=str(getattr(challenge, "difficulty", "") or "unknown"),
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            required_tools=required_tools,
            evidence=tool_evidence_lines,
            extra_facts=extra_facts,
            server_instructions=instructions,
        )
        # The first model's deadline leaves time for one fallback model.
        max_time_s = float(challenge.max_time_s or 0)
        remaining_estimate = (
            float(challenge.time_remaining_s or max_time_s or 0) - (time.monotonic() - challenge_fetched_at)
        )
        first_deadline_s, fallback_s = _solve_budgets(max_time_s, remaining_estimate)
        if first_deadline_s is not None:
            print(f"   Solve deadline: {first_deadline_s:.0f}s for {model_name}, {fallback_s:.0f}s kept for a fallback")

        ticker = ReasoningTicker(model_name)
        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await solve_challenge(
            challenge,
            clues,
            llm_client,
            model_name,
            strategy,
            solve_ctx,
            http_client=http_client,
            agent_id=agent_id,
            broadcast_thought=True,
            evidence_lines=tool_evidence_lines,
            ticker=ticker,
            deadline_s=first_deadline_s,
        )
        ticker.finish()
        async def _remaining_s() -> float:
            info = await mcp_client.time_remaining(agent_id)
            return float(info.get("time_remaining_s", 0.0))

        def _solve_with(retry_model: str, deadline_s: float | None = None):
            nonlocal ticker
            http_client.broadcast_thought(agent_id, f"Retrying with {retry_model}...")
            ticker = ReasoningTicker(retry_model)
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                retry_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
                deadline_s=deadline_s,
            )

        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_with_next_model(
            (answer, raw_response, model_name, usage, ttft_ms, total_time_ms),
            ranked_models=ranked_models,
            remaining_s=_remaining_s,
            solve_with=_solve_with,
            max_time_s=max_time_s,
        )
        ticker.finish()
        for line in summary_lines(
            model=model_name,
            elapsed_s=total_time_ms / 1000,
            usage=usage,
            finish_reason=str(usage.get("finish_reason") or ""),
            answer=answer,
            ticker=ticker,
        ):
            print(line)
        
        if _is_invalid_answer_candidate(answer):
            answer = ""
        if not answer:
            print("   ⚠️  No valid ANSWER format found; using last line as fallback.")
            lines = raw_response.strip().splitlines()
            last_line = lines[-1].strip().strip("`\"'") if lines else ""
            answer = (
                last_line
                if last_line and len(last_line) < 400 and not _is_invalid_answer_candidate(last_line)
                else "unknown"
            )

        # Save draft with extracted answer as backup
        http_client.save_draft(agent_id, answer, "LLM solution")
        http_client.broadcast_thought(agent_id, f"Answer: {answer}")
        
        # Check time remaining
        time_info = await mcp_client.time_remaining(agent_id)
        called_tools.add("arena.time_remaining")
        remaining_s = float(time_info.get("time_remaining_s", 0.0))
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=str(getattr(challenge, "difficulty", "") or "unknown"),
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
            required_tools=required_tools,
            evidence=tool_evidence_lines,
            extra_facts=extra_facts,
            server_instructions=instructions,
        )
        if strategy.should_submit_early(answer, submit_ctx):
            http_client.broadcast_thought(agent_id, "⚡ Strategy submitting early.")
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        print(f"   Time remaining: {time_info['time_remaining_s']:.1f}s")
    
    # Step 4: Submit the extracted answer with real metrics
    _warn_missing_required_tools(required_tools, called_tools)
    print("\n📤 Submitting answer...")
    http_client.broadcast_thought(agent_id, "Submitting final answer!")
    await _stop_metrics_reporter()
    
    result = http_client.submit(
        agent_id=agent_id,
        answer=answer,
        client_metrics={
            "model_name": model_name,
            "total_tokens": str(live_total_tokens),
            "prompt_tokens": str(live_prompt_tokens),
            "completion_tokens": str(live_completion_tokens),
            "ttft_ms": ttft_ms,
            "total_time_ms": total_time_ms,
        }
    )
    
    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")
    
    await session_monitor.stop()
    # Last steps, after the submission is final; neither raises.
    final_score, score_source = await _report_final_score(http_client, agent_id, result.score, result.status)
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "evidence": tool_evidence_lines,
        "extra_facts": extra_facts,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": final_score if final_score is not None else result.score,
            "score_source": score_source,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
