"""Bounded tool exploration for the custom runtime.

The live server is described as a black box: tools the agent has not seen,
data it must fetch or decode. This module lets the solver model call the
discovered tools for a bounded time, with these rules:

- Tools that submit, broadcast, fetch the challenge or register are never
  offered: the first submission is final, and fetching the challenge starts
  the timer. Image output tools are not offered on text challenges.
- Only advertised names are callable. The model cannot invent a tool.
- `agent_id` is filled in by the runtime, never by the model.
- After every call the tool list is read again, because the server may add
  tools without announcing them; new tools are offered at once.
- Error text goes back to the model as-is, since servers put hints there.
- The loop stops at a call budget, a time budget, or when the model answers
  without a tool call. Its findings join the solver prompt as evidence; the
  loop never submits.

`decode_candidates` handles the plain encodings a puzzle setter is likely to
use (base64, base64url, hex, rot13 and other Caesar shifts, single-byte XOR,
JWT payloads); `image_metadata_text` reads the text chunks of a PNG or JPEG.
Decoded text is offered to the model to verify, not trusted.
`facts_from_evidence` picks the short statements out of tool results so the
strategy can treat them like clues.
"""
from __future__ import annotations

import asyncio
import base64
import binascii
import codecs
import json
import re
import struct
import time
import zlib
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

# Name fragments of tools the loop must never call.
NEVER_CALL = ("submit", "broadcast", "get_challenge", "register")
# Tools that cost seconds and tokens. The main path calls them when the task
# needs an image; the loop never does.
IMAGE_OUTPUT_TOOLS = frozenset({"image_edit", "image_generate"})
# The practice server's tools. A challenge served with only these, and that
# names no tool, takes the single-call path.
CORE_TOOLS = frozenset(
    {
        "arena.get_challenge",
        "arena.clues.list",
        "arena.clues.get",
        "arena.time_remaining",
        "arena.tools.list",
        "arena.image.get_challenge",
        "arena.image.broadcast_thought",
        "arena.image.submit_edit",
        "image_edit",
        "image_generate",
        "image_analyze",
    }
)

MAX_CALLS = 8
TIME_SHARE = 0.35
MIN_BUDGET_S = 8.0
MAX_BUDGET_S = 45.0
RESULT_CHARS = 2000
TOOL_MESSAGE_CHARS = 4000

SYSTEM_PROMPT = (
    "You are gathering information from an MCP server for a timed challenge. "
    "Call the tools to obtain any data the challenge refers to, follow hints in tool "
    "results and error messages, and stop as soon as you have what the challenge needs. "
    "Only the listed tools exist. When you are done, reply without a tool call with a "
    "short summary of what you found; do not solve the challenge here."
)


@dataclass
class ExplorationResult:
    evidence: list[str] = field(default_factory=list)
    called: list[str] = field(default_factory=list)
    new_tools: list[str] = field(default_factory=list)
    summary: str = ""
    stopped: str = ""
    llm_calls: int = 0


def exploration_budget_s(max_time_s: float | int) -> float:
    """Seconds the loop may use: a share of the challenge time, clamped."""
    max_time_s = float(max_time_s or 0)
    if max_time_s <= 0:
        return MIN_BUDGET_S
    return max(MIN_BUDGET_S, min(MAX_BUDGET_S, max_time_s * TIME_SHARE))


def _name(tool_def: object) -> str:
    return str(getattr(tool_def, "name", "") or "").strip()


def is_offerable(name: str, modality: str = "text") -> bool:
    """Whether the loop may call `name`. `modality` is accepted for callers' sake."""
    del modality
    lowered = name.lower()
    if not lowered or any(part in lowered for part in NEVER_CALL):
        return False
    return name not in IMAGE_OUTPUT_TOOLS


def offerable_tools(tool_defs: list, modality: str = "text") -> list:
    return [tool_def for tool_def in tool_defs if is_offerable(_name(tool_def), modality)]


def should_explore(tool_names: list[str], challenge_text: str) -> str:
    """Why the loop should run, or "" when the single-call path is enough."""
    names = [str(name or "").strip() for name in tool_names]
    unknown = [name for name in names if name and name not in CORE_TOOLS and is_offerable(name)]
    if unknown:
        return "tools beyond the known set: " + ", ".join(unknown[:6])
    lowered = (challenge_text or "").lower()
    named = [name for name in names if name and is_offerable(name) and name.lower() in lowered]
    if named:
        return "the challenge names a tool: " + ", ".join(named[:6])
    return ""


def function_definitions(tool_defs: list) -> list[dict[str, Any]]:
    """OpenAI tool definitions from MCP tool definitions, without agent_id."""
    functions: list[dict[str, Any]] = []
    for tool_def in tool_defs:
        name = _name(tool_def)
        if not name:
            continue
        schema = dict(getattr(tool_def, "inputSchema", None) or {})
        properties = {
            key: value
            for key, value in dict(schema.get("properties") or {}).items()
            if key != "agent_id"
        }
        required = [key for key in list(schema.get("required") or []) if key != "agent_id"]
        description = str(getattr(tool_def, "description", "") or "").strip() or f"MCP tool {name}"
        functions.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": description,
                    "parameters": {
                        "type": "object",
                        "properties": properties,
                        "required": required,
                    },
                },
            }
        )
    return functions


def _takes_agent_id(tool_def: object | None) -> bool:
    if tool_def is None:
        return True
    schema = getattr(tool_def, "inputSchema", None) or {}
    return "agent_id" in (schema.get("properties") or {})


def render_result(result: object) -> str:
    """A tool result as text, without inline image data."""
    if isinstance(result, dict):
        cleaned = {
            key: value
            for key, value in result.items()
            if not ("image" in str(key).lower() and isinstance(value, str) and len(value) > 256)
        }
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(cleaned)
    if result is None:
        return ""
    return str(result)


async def explore(
    *,
    llm_client: Any,
    model: str,
    tool_defs: list,
    call_tool: Callable[[str, dict], Awaitable[Any]],
    list_tool_defs: Callable[[], Awaitable[list]],
    agent_id: str,
    challenge_text: str,
    clues: list[str],
    evidence_lines: list[str],
    strategy: Any,
    ctx: Any,
    max_time_s: float | int,
    modality: str = "text",
    budget_s: float | None = None,
    max_calls: int = MAX_CALLS,
    on_event: Callable[[str], Any] | None = None,
) -> ExplorationResult:
    """Let the model call discovered tools, bounded by time and call count."""
    result = ExplorationResult()
    deadline = time.monotonic() + (budget_s if budget_s is not None else exploration_budget_s(max_time_s))
    known = {name: tool_def for tool_def in tool_defs if (name := _name(tool_def))}
    offered = offerable_tools(list(known.values()), modality)
    order = strategy.plan_tools(ctx, [_name(tool_def) for tool_def in offered])
    if isinstance(order, list) and order:
        wanted = [str(name) for name in order]
        offered = [known[name] for name in wanted if name in known and is_offerable(name, modality)]
    functions = function_definitions(offered)
    if not functions:
        result.stopped = "no tools to offer"
        return result
    allowed = {definition["function"]["name"] for definition in functions}

    def emit(message: str) -> None:
        if on_event is not None:
            try:
                on_event(message)
            except Exception:
                pass

    clue_block = "\n".join(f"- {clue}" for clue in clues if str(clue).strip()) or "- (none)"
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if str(line).strip()) or "- (none yet)"
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Challenge:\n{challenge_text.strip()}\n\nClues:\n{clue_block}\n\n"
                f"Already retrieved:\n{evidence_block}\n\n"
                f"You may make at most {max_calls} tool calls."
            ),
        },
    ]

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 1.0:
            result.stopped = "time budget"
            break
        if len(result.called) >= max_calls:
            result.stopped = "call budget"
            break
        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(
                    llm_client.chat.completions.create,
                    model=model,
                    messages=messages,
                    tools=functions,
                    tool_choice="auto",
                    temperature=0.0,
                    max_tokens=1024,
                ),
                timeout=remaining,
            )
        except asyncio.TimeoutError:
            result.stopped = "time budget"
            break
        except Exception as exc:  # the solve step still runs without exploration
            result.stopped = f"llm error: {type(exc).__name__}"
            break
        result.llm_calls += 1
        message = response.choices[0].message
        tool_calls = list(getattr(message, "tool_calls", None) or [])
        content = str(getattr(message, "content", "") or "").strip()
        if not tool_calls:
            result.summary = content
            result.stopped = "done"
            break
        messages.append(
            {
                "role": "assistant",
                "content": content or None,
                "tool_calls": [
                    {
                        "id": call.id,
                        "type": "function",
                        "function": {"name": call.function.name, "arguments": call.function.arguments or "{}"},
                    }
                    for call in tool_calls
                ],
            }
        )
        for call in tool_calls:
            name = str(call.function.name or "")
            if len(result.called) >= max_calls:
                reply = "error: call budget exhausted"
            elif name not in allowed:
                reply = f"error: {name} is not an available tool"
            else:
                try:
                    arguments = json.loads(call.function.arguments or "{}")
                except ValueError:
                    arguments = {}
                if not isinstance(arguments, dict):
                    arguments = {}
                arguments.pop("agent_id", None)
                if _takes_agent_id(known.get(name)):
                    arguments["agent_id"] = agent_id
                emit(f"Exploring: {name}")
                try:
                    tool_result = await call_tool(name, arguments)
                except Exception as exc:
                    tool_result = {"error": f"{type(exc).__name__}: {exc}"}
                result.called.append(name)
                hook_text = strategy.on_tool_result(name, tool_result, ctx)
                rendered = str(hook_text).strip() if hook_text else render_result(tool_result)
                if rendered:
                    result.evidence.append(f"{name}: {rendered[:RESULT_CHARS]}")
                reply = rendered or "(empty result)"
                # The server may have registered tools during the call.
                try:
                    fresh = await list_tool_defs()
                except Exception:
                    fresh = []
                added = []
                for tool_def in fresh:
                    fresh_name = _name(tool_def)
                    if fresh_name and fresh_name not in known:
                        known[fresh_name] = tool_def
                        added.append(fresh_name)
                        if is_offerable(fresh_name, modality):
                            functions.extend(function_definitions([tool_def]))
                            allowed.add(fresh_name)
                if added:
                    result.new_tools.extend(added)
                    emit(f"New tools: {', '.join(added)}")
            messages.append({"role": "tool", "tool_call_id": call.id, "content": reply[:TOOL_MESSAGE_CHARS]})
        if result.new_tools and any(name in result.new_tools for name in allowed):
            messages.append(
                {"role": "user", "content": "New tools are now available: " + ", ".join(result.new_tools)}
            )
    return result


# --- plain decodings -------------------------------------------------------

_BASE64_RE = re.compile(r"(?<![A-Za-z0-9+/=_-])[A-Za-z0-9+/_-]{16,}={0,2}(?![A-Za-z0-9+/=_-])")
_HEX_RE = re.compile(r"(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{2}){8,}(?![0-9A-Fa-f])")
_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}(?:\.[A-Za-z0-9_-]*)?")
_WORDS = frozenset(
    "the and is of to in a for with key code answer clue order first last before after "
    "not at on by from this that are was be it as or you your "
    # Puzzle vocabulary, so a short shifted sentence still registers.
    "second third fourth fifth sixth left right next between than more less under over "
    "behind front door red blue green yellow one two three four five six who what where when "
    "which has have had did does do no yes but if then so an my we they he she his her their "
    "them there here all any each every some only also into out up down about same other "
    "number letter word name names person people finished finish started start end wins won "
    "lost sits sat stands lives owns likes drinks eats wears immediately directly somewhere "
    "exactly neither nor either both none always never true false lies lie truth knight knave "
    "says said tells told vault note hidden secret password unlock open locked find look".split()
)


def _looks_like_text(value: str) -> bool:
    if not value or not value.isprintable():
        return False
    letters = sum(char.isalpha() for char in value)
    return letters >= max(3, len(value) // 2)


def _english_score(value: str) -> int:
    # One-letter words ("a", "I") are too easy to hit by chance and do not count.
    return sum(1 for word in re.findall(r"[a-z']{2,}", value.lower()) if word in _WORDS)


def _shift(text: str, amount: int) -> str:
    out = []
    for char in text:
        if "a" <= char <= "z":
            out.append(chr((ord(char) - 97 + amount) % 26 + 97))
        elif "A" <= char <= "Z":
            out.append(chr((ord(char) - 65 + amount) % 26 + 65))
        else:
            out.append(char)
    return "".join(out)


def _caesar_candidate(text: str) -> tuple[str, str] | None:
    """The one shift that reads as English when the text itself does not."""
    if len(re.findall(r"\b[A-Za-z]{2,}\b", text)) < 3:
        return None
    baseline = _english_score(text)
    scored = sorted(
        ((_english_score(_shift(text, amount)), amount) for amount in range(1, 26)),
        reverse=True,
    )
    best_score, best_shift = scored[0]
    if best_score < 2 or best_score <= baseline or (len(scored) > 1 and scored[1][0] == best_score):
        return None
    scheme = "rot13" if best_shift == 13 else f"caesar-{best_shift}"
    return scheme, _shift(text, best_shift)


def _xor_candidate(data: bytes) -> str | None:
    """A single-byte XOR of `data` that reads as English, if exactly one does."""
    if len(data) < 8:
        return None
    hits: list[tuple[int, str]] = []
    for key in range(1, 256):
        try:
            decoded = bytes(byte ^ key for byte in data).decode("utf-8")
        except UnicodeDecodeError:
            continue
        if _looks_like_text(decoded):
            score = _english_score(decoded)
            if score >= 3:
                hits.append((score, decoded))
    if not hits:
        return None
    hits.sort(reverse=True)
    if len(hits) > 1 and hits[1][0] == hits[0][0]:
        return None
    return hits[0][1]


def _plausible_base64(token: str) -> bool:
    """Not a long word or a hyphenated phrase: real base64 mixes case or has digits."""
    if re.search(r"[0-9+/=]", token):
        return True
    return token != token.lower() and token != token.upper()


def _b64(token: str) -> bytes | None:
    padded = token + "=" * (-len(token) % 4)
    try:
        if "-" in token or "_" in token:
            return base64.urlsafe_b64decode(padded)
        return base64.b64decode(padded, validate=True)
    except (binascii.Error, ValueError):
        return None


def _utf8(data: bytes) -> str | None:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def decode_candidates(text: str) -> list[tuple[str, str]]:
    """(scheme, decoded) pairs for encoded runs in `text`; only readable results."""
    found: list[tuple[str, str]] = []
    if not isinstance(text, str) or not text.strip():
        return found
    jwt_spans: list[tuple[int, int]] = []
    for match in _JWT_RE.finditer(text):
        parts = match.group(0).split(".")
        payload = _b64(parts[1])
        decoded = _utf8(payload) if payload else None
        if decoded and decoded.lstrip().startswith("{"):
            found.append(("jwt", decoded))
            jwt_spans.append(match.span())
    for match in _BASE64_RE.finditer(text):
        token = match.group(0)
        if any(start <= match.start() < end for start, end in jwt_spans):
            continue  # a segment of a token decoded above
        if re.fullmatch(r"[0-9A-Fa-f]+", token) or not _plausible_base64(token):
            continue  # a hex run (handled below), or a word
        data = _b64(token)
        if data is None:
            continue
        decoded = _utf8(data)
        if decoded is not None and _looks_like_text(decoded):
            found.append(("base64", decoded))
            continue
        xored = _xor_candidate(data)
        if xored:
            found.append(("base64+xor", xored))
    for match in _HEX_RE.finditer(text):
        data = bytes.fromhex(match.group(0))
        decoded = _utf8(data)
        if decoded is not None and _looks_like_text(decoded):
            found.append(("hex", decoded))
            continue
        xored = _xor_candidate(data)
        if xored:
            found.append(("hex+xor", xored))
    # A JSON body is decoded value by value by `decoded_evidence`; shifting
    # the keys along with the values only garbles it.
    if "{" not in text and "}" not in text:
        caesar = _caesar_candidate(text)
        if caesar:
            found.append(caesar)
    return found


def _string_values(value: object, prefix: str = "") -> list[tuple[str, str]]:
    """(path, text) for every string inside a JSON value."""
    if isinstance(value, str):
        return [(prefix, value)]
    if isinstance(value, dict):
        return [pair for key, item in value.items() for pair in _string_values(item, f"{prefix}.{key}" if prefix else str(key))]
    if isinstance(value, list):
        return [pair for index, item in enumerate(value) for pair in _string_values(item, f"{prefix}[{index}]")]
    return []


def decoded_evidence(sources: dict[str, str]) -> list[str]:
    """Evidence lines for every decodable value in `sources` ({label: text}).

    An evidence line whose body is JSON is also decoded value by value, since
    a shifted sentence inside a result is unreadable as part of the whole line.
    """
    lines: list[str] = []
    seen: set[str] = set()

    def add(label: str, text: str) -> None:
        for scheme, decoded in decode_candidates(text):
            key = f"{scheme}:{decoded}"
            if key in seen:
                continue
            seen.add(key)
            lines.append(f"decoded({label}, {scheme}): {decoded[:RESULT_CHARS]}")

    for label, text in sources.items():
        if not isinstance(text, str):
            continue
        add(label, text)
        _, sep, body = text.partition(": ")
        body = body.strip() if sep else ""
        if body.startswith(("{", "[")):
            try:
                data = json.loads(body)
            except ValueError:
                continue
            for path, value in _string_values(data):
                if len(value) >= FACT_MIN_CHARS:
                    add(f"{label}.{path}" if path else label, value)
    return lines


# --- image metadata --------------------------------------------------------

_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_PNG_TEXT_CHUNKS = {b"tEXt", b"iTXt", b"zTXt"}
_JPEG_TEXT_MARKERS = {0xFE, 0xE1}  # COM, APP1 (EXIF / XMP)


def image_bytes_from_uri(uri: str) -> bytes | None:
    """The bytes of a data: URI, else None (remote URLs are not fetched)."""
    if not isinstance(uri, str) or not uri.startswith("data:"):
        return None
    header, sep, payload = uri.partition(",")
    if not sep:
        return None
    try:
        if ";base64" in header:
            return base64.b64decode(payload + "=" * (-len(payload) % 4))
        return payload.encode("latin-1")
    except (binascii.Error, ValueError, UnicodeEncodeError):
        return None


def _png_text(data: bytes) -> list[str]:
    texts: list[str] = []
    offset = len(_PNG_SIGNATURE)
    while offset + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[offset : offset + 8])
        body = data[offset + 8 : offset + 8 + length]
        offset += 12 + length
        if kind not in _PNG_TEXT_CHUNKS:
            if kind == b"IEND":
                break
            continue
        keyword, _, rest = body.partition(b"\x00")
        try:
            if kind == b"tEXt":
                value = rest.decode("latin-1")
            elif kind == b"zTXt":
                value = zlib.decompress(rest[1:]).decode("latin-1")
            else:  # iTXt: compression flag, method, language, translated keyword, text
                compressed = rest[:1] == b"\x01"
                tail = rest[2:].split(b"\x00", 2)
                raw = tail[2] if len(tail) == 3 else b""
                value = (zlib.decompress(raw) if compressed else raw).decode("utf-8")
        except (zlib.error, UnicodeDecodeError, IndexError):
            continue
        value = value.strip()
        if value:
            texts.append(f"{keyword.decode('latin-1', 'replace')}: {value}")
    return texts


def _jpeg_text(data: bytes) -> list[str]:
    texts: list[str] = []
    offset = 2
    while offset + 4 <= len(data) and data[offset] == 0xFF:
        marker = data[offset + 1]
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            offset += 2
            continue
        length = struct.unpack(">H", data[offset + 2 : offset + 4])[0]
        body = data[offset + 4 : offset + 2 + length]
        offset += 2 + length
        if marker == 0xDA:  # start of scan: no more headers
            break
        if marker not in _JPEG_TEXT_MARKERS:
            continue
        runs = re.findall(rb"[\x20-\x7e]{8,}", body)
        for run in runs:
            value = run.decode("ascii").strip()
            if value and not value.startswith(("http://ns.adobe", "<?xpacket")):
                texts.append(value)
    return texts


def image_metadata_text(uri: str) -> list[str]:
    """Readable text stored in a PNG or JPEG data URI (comments, EXIF, XMP)."""
    data = image_bytes_from_uri(uri)
    if not data:
        return []
    try:
        if data.startswith(_PNG_SIGNATURE):
            return _png_text(data)
        if data[:2] == b"\xff\xd8":
            return _jpeg_text(data)
    except Exception:
        return []
    return []


# --- facts for the strategy --------------------------------------------------

# Result keys whose string values tend to be statements about the puzzle.
FACT_KEYS = (
    "text", "note", "notes", "clue", "clues", "hint", "hints", "fact", "facts",
    "message", "content", "value", "answer", "secret", "data", "description",
)
FACT_MIN_CHARS = 8
FACT_MAX_CHARS = 400
MAX_FACTS = 12


def _fact_strings(value: object) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        if FACT_MIN_CHARS <= len(text) <= FACT_MAX_CHARS and not text.startswith(("{", "[", "data:")):
            return [text]
        return []
    if isinstance(value, list):
        return [fact for item in value for fact in _fact_strings(item)]
    if isinstance(value, dict):
        return [fact for key in FACT_KEYS if key in value for fact in _fact_strings(value[key])]
    return []


def facts_from_evidence(evidence_lines: list[str], known_texts: list[str] | None = None) -> list[str]:
    """Short statements found in tool results and decodings, new ones only.

    Each evidence line is `source: body`. Decoded text is a fact; a JSON body
    contributes the string values under FACT_KEYS; a plain body is a fact
    itself. Errors, bookkeeping and anything already in `known_texts` are
    left out. The strategy may treat these like clues (checked, not trusted).
    """
    known = {text.strip() for text in (known_texts or []) if str(text).strip()}
    facts: list[str] = []
    for line in evidence_lines or []:
        source, sep, body = str(line).partition(": ")
        if not sep or not body.strip():
            continue
        if source.startswith("exploration"):
            continue
        candidates: list[str]
        if source.startswith("decoded("):
            candidates = _fact_strings(body)
        else:
            try:
                data: object = json.loads(body)
            except ValueError:
                data = body
            if isinstance(data, dict) and data.get("error"):
                continue
            candidates = _fact_strings(data)
        for fact in candidates:
            if fact in known or fact in facts or any(fact in text for text in known):
                continue
            if not source.startswith("decoded(") and decode_candidates(fact):
                continue  # the decoded form is its own evidence line
            facts.append(fact)
            if len(facts) >= MAX_FACTS:
                return facts
    return facts
